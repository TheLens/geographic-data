LASC_(1997)_-_To_nearest_2010_Census_Block

Files when supplied by Bill Blair (La. House demographer) ahead of the Oct. 12, 2019, election.

These show the current state supreme court districts (last updated in 1997) as approximated with 2010 census blocks.

Because the original supreme court districts were defined based on precincts in 1997, which aligned with census blocks from the 1990 election, they no longer align with modern census blocks and precincts.

After the 2010 census, Bill chose the 2010 census blocks that were closest to the 1997 supreme court districts. While certainly off from the exact 1997 boundaries, this is a good enough approximation for district-wide views.

The La. Sec. of State. maintains a list of which modern precincts are contained in each supreme court district. This must be requested and may charge a fee. Even still, this list will include some precincts that say “(PT)” because only a part of those precincts are in the 1997 boundaries.

This is also an issue for judicial districts. For both sets of districts, their definitions don’t update as the precincts and census blocks that they were based upon change.
